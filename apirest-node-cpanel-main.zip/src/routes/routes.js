const express = require('express');
const router = express();
const multer = require('multer')
const bookController = require('../controllers/book.controller');
const HoraController = require('../controllers/horacontroller');
const trabajadorController = require('../controllers/trabajadorcontroller')
const saludController = require('../controllers/saludcontroller')
const correoController = require('../controllers/mailercontroller')
const montesController = require('../controllers/clientesMontescontroller')
const correoMontesController = require('../controllers/correoMontesController')
const comprasHabitatController = require('../controllers/compras.controller')
const mercadoPago = require('../controllers/mercadoPago')
const album = require('../controllers/feedback')
const inventario = require('../controllers/inventariocontroller')
const ajustes = require('../controllers/ajustescontrollers')


const storage = multer.diskStorage(
{
    filename: function(res, file, cb){
    const ext = file.originalname.split('.').pop()
    const fileName = Date.now();
    cb(null, `${fileName}.${ext}`)
    },
    destination:function(res, file, cb){
    cb(null, './fotostrabajadores')
    }
}
)
const upload = multer({storage})

module.exports = () => {
    router.get('/books', bookController.getBooks);
    router.get('/books/:id', bookController.getBookById);
    router.post('/books', bookController.createBook);
    router.put('/books/:id', bookController.updateBookById);
    router.delete('/books/:id', bookController.deleteBookById);


    router.get('/hora', HoraController.getHora);
    router.post('/hora', HoraController.createHora);

    router.get('/trabajador', trabajadorController.getTrabajador);
    // router.get('/trabajador/:cedula', trabajadorController.consultaOneClients);
    router.post('/trabajador', trabajadorController.createTrabajador);
    router.put('/trabajador/:id', trabajadorController.updateTrabajador);
    // router.delete('/trabajador/:id', trabajadorController.deleteClients);

    router.get('/salud', saludController.getSalud);
    router.get('/salud/:cedula', saludController.getSaludId);

    router.post('/correo',correoController.enviarCorreo)


    //montes
    router.post('/montes', montesController.createCliente)
    router.post('/correoJhon',correoMontesController.enviarCorreo)

    //compras
    router.get('/empleados', comprasHabitatController.getCompras_empleados);
    router.get('/pedidos', comprasHabitatController.getPedido);
    router.post('/orden', comprasHabitatController.createOrden);
    router.put('/estado/:id', comprasHabitatController.actualizarOrden);
    router.put('/notas/:id', comprasHabitatController.actualizarCompras);
    router.post('/clientes', montesController.createCliente);
    router.post('/proveedor', montesController.createProveedor)


    // mercadopago
    router.post('/mercadoPago', mercadoPago.mercadopagoPay);
    router.post('/album',upload.single('myFile'), album);
    
    // rutas del inventario
    router.post('/inventario', inventario.newCantidad)
    router.get('/getinventario', inventario.getCantidad)
    router.delete('/deleteCantidad/:id', inventario.deleteCantidad);
    
    router.get('/getItems', inventario.getItems)
    router.post('/newItems', inventario.newItems)
    router.put('/updateItem/:id', inventario.updateItem)

    router.post('/newProyecto', inventario.newProyectos)
    router.get('/getProyectos', inventario.getProyectos)
    
    router.post('/newMateriales', inventario.newMateriales)
    router.get('/getMateriales', inventario.getMateriales)
    router.delete('/deleteMat/:id', inventario.deleteMat)

    router.post('/newMaterial', inventario.newMaterial)
    router.get('/getMaterial', inventario.getMaterial)

    router.post('/postUbicacionObra', ajustes.newUbicacionObra)
    router.get('/getUbicaionObra', ajustes.getUbicacionObra)
    router.post('/newContratista', ajustes.newContratista)
    router.get('/getContratista', ajustes.getContratista)
    router.post('/newProveedor', ajustes.newProveedor)
    router.get('/getProveedor', ajustes.getProveedor)




    return router;

}