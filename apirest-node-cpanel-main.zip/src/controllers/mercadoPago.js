exports.mercadopagoPay = async (req, res) => {
    
    const values = req.body
    console.log(req)
    const respuestaPayu = req.body;
    console.log(respuestaPayu);

    const sql = "INSERT INTO pruebasConfirmacion(pruebas) VALUES(?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
            res.json({ message: "Error al guardar proveedor en BD",clave: 9747 });
        return
        }
        res.json({message: "proveedor guardado con exito",clave: 1077})
        return
    })
}

