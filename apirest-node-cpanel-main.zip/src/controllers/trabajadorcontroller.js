const pool = require("../config/conexion");
const multer = require('multer');



exports.createTrabajador = (req, res) => {
    const values = Object.values(req.body)
    console.log(values)

    const sql = "INSERT INTO trabajadores(cedula, nombre,fecha_expedicion, obra, cargo, quien_lo_contracto, foto) VALUES(?, ?, ?, ?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error al guardar en BD" });
        return
        }
        res.json({message: "Trabajador creado con exito"})
    })
}

exports.updateTrabajador = (req, res) =>{
  const values = Object.values(req.body)
  const ID = req.params.id;
  const sql = "UPDATE trabajadores SET cedula=?, nombre=?, fecha_expedicion=?, obra=?, cargo=?, quien_lo_contracto=?, foto=? WHERE id=?"
  pool.query(sql, [...values, ID], (err, result, fields) => {
    if(err){
        res.json({ message: "Error al guardar en BD" });
        return
    }
    res.json({message: "Trabajador actualizado con exito"})
  })
}

exports.getTrabajador= (req, res) => {
  const sql = "SELECT * FROM trabajadores;";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      console.log(err)
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}

exports.albumTrabajadores = ( req, res ) => {
  console.log(req.body)
  const storage = multer.diskStorage(
    {
      filename: function(res, file, cb){
        const ext = file.originalname.split('.').pop()
        console.log(ext);
        const fileName = Date.now();
        cb(null, `${fileName}.${ext}`)
      },
      destination:function(res, file, cb){
        cb(null, `../archivos`)
      }
    }
  )
  console.log(storage)
  const upload = multer({storage})
  upload.single('myFile')
  console.log(upload)
  res.send({data:'respuesta del servidor del album'})
}