const pool = require("../config/conexion");

// exports.getclienteMontes = (req, res) => {
//   const sql = "SELECT * FROM registro_entrada_salida;";
//   pool.query(sql, (err, result, fields) => {
//     if(err) {
//       res.json({ message: "Error en la consulta" });
//     }
//     res.json(result)
//   })
// }

exports.createCliente = (req, res) => {
    const values = Object.values(req.body)

    const sql = "INSERT INTO clientesResidentes(nombre, correo, celular, tipo) VALUES(?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
            res.json({ message: "Error al guardar en BD",clave: 9747 });
        return
        }
        res.json({message: "guardado con exito",clave: 1077})
        return
    })
}

exports.createProveedor = (req, res) => {
    const values = Object.values(req.body)

    const sql = "INSERT INTO proveedores(nameEmpresa, nameEmpleado, lugar, placa, cedula, celular) VALUES(?, ?, ?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
            res.json({ message: "Error al guardar proveedor en BD",clave: 9747 });
        return
        }
        res.json({message: "proveedor guardado con exito",clave: 1077})
        return
    })
}