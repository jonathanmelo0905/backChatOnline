const pool = require("../config/conexion");

exports.getSalud= (req, res) => {
  const sql = "SELECT * FROM seguridads_social;";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}

exports.getSaludId = (req, res) => {
    const ID = req.params.cedula;
  
    const sql = "SELECT * FROM seguridads_social WHERE id=?";
    pool.query(sql,[ID], (err, result, fields) => {
      if(err) {
        res.json({ message: "Error en la consulta" });
        return
      }
      res.json(result)
    })
  }