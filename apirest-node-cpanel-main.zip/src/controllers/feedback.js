const multer = require('multer')
const express = require('express');
const router = express();



module.exports = ((req, res) => {
	const file = req.file
	console.log(file)
	res.send({data:'respuesta del servidor del album', url: file.filename})
})