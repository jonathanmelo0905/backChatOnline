"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const mailer_1 = require("../config/correoMontes");
exports.enviarCorreo = (req, res) => {
        return __awaiter(this, void 0, void 0, function* () {
            console.log(req.body);
            const nombre = req.body.nombre;
            const id = req.body.id_empleado;
            const fecha = req.body.fecha_pedido;
            const date = new Date();
            const prioridad = req.body.caracter;
            try {
                yield mailer_1.transporter.sendMail({
                    from: '"Sistema de peidos Habitat" <compras@habitatconstructores.com>',
                    to: 'compras@habitatconstructores.com',
                    subject: `se realizo nuevo pedido: ${date}`,
                    text: "Hello world?",
                    html: `
                    <h1>Nuevo pedido realizado por:</h1>
                    <h1>${nombre}</h1>
                    <h2>fecha:</h2>
                    <h2>${fecha}</h2>
                    <h2>prioridad:</h3>
                    <h2>${prioridad}</h2>
                    <h2>Revisar en la lista de pedidos en la pagina entrando en el siguiente link:</h2>
                    <h1>https://desarrollosjm.store/#/ver-pedidos</h1>
                    `,
                });
                res.json({ ok: "correo enviado" });
                return;
            }
            catch (error) {
                console.log(error);
                return;
            }
        });
    }

