const pool = require("../config/conexion");

exports.getBooks = (req, res) => {
  const sql = "SELECT * FROM trabajadores;";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}

exports.getBookById = (req, res) => {
  const ID = req.params.id;

  const sql = "SELECT * FROM books WHERE id=?";
  pool.query(sql,[ID], (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
    return
  })
}

exports.createBook = (req, res) => {
  console.log(req.params,'mensaje que llega del req')
  const texto = req.body;
  const pruebas = req.params;
  const values = JSON.stringify(texto);
  console.log("🚀 ~ file: book.controller.js:30 ~ values", values)
  const sql = "INSERT INTO confirmacionPayu(resCompra) VALUES(?)";
  pool.query(sql, values, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error al guardar en BD" });
      return
    }
    res.json({message: "Nuevo libro agregado"})
  })
}

exports.updateBookById = (req, res) => {
  const values = Object.values(req.body);
  const ID = req.params.id;

  const sql = "UPDATE books SET title=?, summary=?, url_image=? WHERE id=?";
  pool.query(sql, [...values, ID], (err, result, fields) => {
    if(err) {
      res.json({ message: "Error al actualizar" });
      return
    }
    res.json({message: "Libro actualizado"})
  })
}

exports.deleteBookById = (req, res) => {
  const ID = req.params.id;

  const sql = "DELETE FROM books WHERE id=?";
  pool.query(sql, ID, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error al eliminar" });
      return
    }
    res.json({message: "Un libro eliminado"})
  })
}