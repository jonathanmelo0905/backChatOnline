const pool = require("../config/conexion");

exports.getCompras_empleados= (req, res) => {
    console.log('entrando aqui')
  const sql = "SELECT * FROM compras__empleados;";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}
exports.getPedido= (req, res) => {
  console.log('entrando aqui')
  const sql = "SELECT * FROM compras__pedidos;";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}
exports.actualizarOrden= (req, res) => {
  const values = Object.values(req.body);
  const ID = req.params.id;
  console.log(ID,values)
  const sql = "UPDATE compras__pedidos SET estado=? WHERE id=?";
  pool.query(sql, [...values, ID], (err, result, fields) => {
    if(err) {
      res.json({ message: "Error al actualizar" });
      return
    }
    res.json({message: "Libro actualizado"})
  })
}

exports.createOrden = (req, res) => {
    const values = Object.values(req.body)

    const sql = "INSERT INTO compras__pedidos(id_empleado,nombre,materiales,cantidad,und_medida,caracter,fecha_pedido,pedido_para,sub_para,estado,actividad, descripcion,checkbox,comentario) VALUES(?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
          console.log(err)
        res.json({ message: "Error al guardar en BD",clave: 9747 });
        return
        }
        res.json({message: "Orden guardado con exito",clave: 1077})
    })
}

exports.actualizarCompras = (req, res) =>{
  const values = Object.values(req.body)
  const ID = req.params.id;
  const sql = "UPDATE compras__pedidos SET checkbox=?, comentario=? WHERE id=?"
  pool.query(sql, [...values, ID], (err, result, fields) => {
    if(err){
      res.json({ message: "Error al guardar en BD",clave: 0996 });
        return
    }
    res.json({message: "Nota guardado con exito",clave: 0905})
  })
}