const pool = require("../config/conexion");

exports.getHora = (req, res) => {
  const sql = "SELECT * FROM registro_entrada_salida;";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}

exports.createHora = (req, res) => {
    const values = Object.values(req.body)
    console.log("🚀 ~ file: horacontroller.js:16 ~ values", values)

    const sql = "INSERT INTO registro_entrada_salida(cedula, registro, hora, fecha, obra, herramientas) VALUES(?, ?, ?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "El registro fallo, vuelva intentarlo" });
        return
        }
        res.json({message: "Registro exitoso"})
    })
}