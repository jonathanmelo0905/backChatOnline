const pool = require("../config/conexion");

exports.getUbicacionObra = (req, res) => {
    const sql = "SELECT * FROM ubiacionobra";
    pool.query(sql, (err, result, fields) => {
      if(err) {
        res.json({ message: "Error en la consulta" });
        return
      }
      res.json(result)
    })
}

exports.newUbicacionObra = (req, res) =>{
    const values = Object.values(req.body)
    console.log(values)
    const sql = "INSERT INTO ubiacionobra(name) VALUES(?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error al guardar" });
        return
        }
        res.json({message: "se guardo exitosamente"})
    })
}

exports.newContratista = (req, res) =>{
    const values = Object.values(req.body)
    console.log(values)
    const sql = "INSERT INTO ajustes__contractistas(contractista, cedula) VALUES(?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error al guardar" });
        return
        }
        res.json({message: "se guardo exitosamente"})
    })
}

exports.getContratista = (req, res) => {
  const sql = "SELECT * FROM ajustes__contractistas";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}

exports.newProveedor = (req, res) =>{
  const values = Object.values(req.body)
  console.log(values)
  const sql = "INSERT INTO ajustes__proveedores(name, nit) VALUES(?, ?)";
  pool.query(sql, values, (err, result, fields) => {
      if(err) {
      res.json({ message: "Error al guardar" });
      return
      }
      res.json({message: "se guardo exitosamente"})
  })
}

exports.getProveedor = (req, res) => {
  const sql = "SELECT * FROM ajustes__proveedores";
  pool.query(sql, (err, result, fields) => {
    if(err) {
      res.json({ message: "Error en la consulta" });
      return
    }
    res.json(result)
  })
}

