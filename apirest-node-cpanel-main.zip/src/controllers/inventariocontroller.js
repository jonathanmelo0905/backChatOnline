const pool = require("../config/conexion");

exports.newCantidad = (req, res) =>{
    const values = Object.values(req.body)
    console.log(values)
    const sql = "INSERT INTO inventario_asignaciones(id, und_m, id_name, cant, fecha, descripcion, id_mat) VALUES(?, ?, ?, ?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error al guardar" });
        return
        }
        res.json({message: "se guardo exitosamente"})
    })
}

exports.getCantidad = (req, res) =>{
    const sql = "SELECT * FROM inventario_asignaciones;";
    pool.query(sql, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error en la consulta" });
        return
        }
        res.json(result)
    })
}

exports.deleteCantidad = (req, res) => {
    const ID = req.params.id;
    console.log("🚀 ~ file: inventariocontroller.js:29 ~ exports.deleteCantidad ~ ID", ID)
    const id = parseInt(ID);
     
    const sql = "DELETE FROM inventario_asignaciones WHERE id_mat = ?";
    pool.query(sql, id, (err, result, fields) => {
      if(err) {
        res.json({ message: "Error al eliminar" });
        return
      }
      res.json({message: "cantidad eliminada con exito jm"})
    })
}

exports.newItems = (req, res) =>{
    const values = Object.values(req.body)
    console.log(values)
    const sql = "INSERT INTO inventario_items(id, name, id_name, amount, undM) VALUES(?, ?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error al guardar items" });
        return
        }
        res.json({message: "se guardo exitosamente"})
    })
}

exports.getItems = (req, res) =>{
    const sql = "SELECT * FROM inventario_items";
    pool.query(sql, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error en la consulta" });
        return
        }
        res.json(result)
    })
}

exports.updateItem = (req, res) => {
    const values = Object.values(req.body);
    const ID = req.params.id;
    const sql = "UPDATE inventario_items SET id=?, name=?, id_name=?, amount = ?, undM = ? WHERE id_item=?";
    pool.query(sql, [...values, ID], (err, result, fields) => {
      if(err) {
        res.json({ message: "Error al actualizar" });
        return
      }
      res.json({message: "Libro actualizado"})
    })
}

exports.newProyectos = (req, res) =>{
    const values = Object.values(req.body)
    console.log(values)
    const sql = "INSERT INTO inventario_proyectos(name, descripcion) VALUES(?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error al guardar" });
        return
        }
        res.json({message: "se guardo exitosamente"})
    })
}

exports.getProyectos = (req, res) =>{
    const sql = "SELECT * FROM inventario_proyectos";
    pool.query(sql, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error en la consulta" });
        return
        }
        res.json(result)
    })
}

exports.newMateriales = (req, res) =>{
    const values = Object.values(req.body)
    console.log(values)
    const sql = "INSERT INTO inventario_materiales(id_name, name, amount, undM, fecha, placa, proveedor, marca, id_mat) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
            console.log(err)
        res.json({ message: "Error al guardar2" });
        return
        }
        res.json({message: "se guardo exitosamente"})
    })
}

exports.getMateriales = (req, res) =>{
    const sql = "SELECT * FROM inventario_materiales";
    pool.query(sql, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error en la consulta" });
        return
        }
        res.json(result)
    })
}

exports.deleteMat = (req, res) => {
    const ID = req.params.id;
    const id = parseInt(ID);
    console.log("🚀 ~ file: inventariocontroller.js:31 ~ exports.deleteCantidad ~ id", id)
    
    const sql = "DELETE FROM inventario_materiales WHERE id_mat = ?";
    pool.query(sql, id, (err, result, fields) => {
      if(err) {
        res.json({ message: "Error al eliminar" });
        return
      }
      res.json({message: "cantidad eliminada con exito jm"})
    })
}

exports.newMaterial = (req, res) =>{
    const values = Object.values(req.body)
    console.log(values)
    const sql = "INSERT INTO material_ingresado(name, undM) VALUES(?, ?)";
    pool.query(sql, values, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error al guardar3" });
        return
        }
        res.json({message: "se guardo exitosamente"})
    })
}

exports.getMaterial = (req, res) =>{
    const sql = "SELECT * FROM material_ingresado";
    pool.query(sql, (err, result, fields) => {
        if(err) {
        res.json({ message: "Error en la consulta" });
        return
        }
        res.json(result)
    })
}

